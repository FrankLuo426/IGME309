#pragma once
/*---------------------------------------------------------------------------------------
-----------
This project was generated in 2018
-----------------------------------------------------------------------------------------
---------*/
#ifndef _MAIN_H
#define _MAIN_H
#include <iostream>

// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include "GL\glew.h"
#include "GLFW\glfw3.h"
#include "GLM\glm.hpp"
#include "OpenGL-Tutorials\shader.hpp"
#endif //_MAIN_H